# Brandon Parkerson

from pymongo import MongoClient

class AnimalShelter:
    """
    A class to perform CRUD operations on the 'animals' collection
    in the AAC MongoDB database.
    """

    def __init__(self, user, pwd, host='localhost', port=39329, auth_db='AAC'):
        """Initialize connection to MongoDB using provided credentials."""
        connection_uri = f"mongodb://{user}:{pwd}@{host}:{port}/test?authSource={auth_db}"
        self.client = MongoClient(connection_uri)
        self.db = self.client[auth_db]

    def create(self, document):
        """Insert a single document into the animals collection."""
        if not document:
            raise ValueError("No data provided for insertion.")
        result = self.db.animals.insert_one(document)
        return result.acknowledged

    def read(self, query=None):
        """
        Retrieve documents matching the query.
        Returns a cursor to the documents without the _id field.
        """
        query = query or {}
        return self.db.animals.find(query, {'_id': False})

    def update(self, filter_criteria, updates):
        """
        Update documents matching filter_criteria with the updates dict.
        Returns the raw result from the update operation.
        """
        if not filter_criteria:
            raise ValueError("No criteria provided for update.")
        if self.db.animals.count_documents(filter_criteria, limit=1) == 0:
            return "No documents matched the update criteria."
        result = self.db.animals.update_many(filter_criteria, {'$set': updates})
        return result.raw_result

    def delete(self, filter_criteria):
        """
        Delete documents matching the filter criteria.
        Returns the raw result from the delete operation.
        """
        if not filter_criteria:
            raise ValueError("No criteria provided for deletion.")
        if self.db.animals.count_documents(filter_criteria, limit=1) == 0:
            return "No documents matched the deletion criteria."
        result = self.db.animals.delete_many(filter_criteria)
        return result.raw_result

    # Additional helper methods for common queries

    def get_all_animals(self):
        """Return all documents from the animals collection."""
        return list(self.read())

    def find_by_rescue_type(self, rescue_type):
        """Return animals filtered by their rescue type."""
        return list(self.read({"rescueType": rescue_type}))

    def find_by_breed(self, breed_name):
        """Return animals of a specific breed."""
        return list(self.read({"breed": breed_name}))

    def find_by_max_age(self, max_age_weeks=104):
        """Return animals no older than max_age_weeks (default 2 years)."""
        return list(self.read({"age_upon_outcome_in_weeks": {"$lte": max_age_weeks}}))

    def filtered_search(self, rescue_type=None, breeds=None, sex=None, age_range=None):
        """
        Flexible filter to search animals by rescue type, breeds, sex, and age.
        age_range should be a dict like {"$gte": min_weeks, "$lte": max_weeks}.
        """
        query = {"animal_type": "Dog"}

        if rescue_type:
            query["rescueType"] = rescue_type
        if breeds:
            query["breed"] = {"$in": breeds}
        if sex:
            query["sex_upon_outcome"] = sex
        if age_range:
            query["age_upon_outcome_in_weeks"] = age_range

        return list(self.read(query))
